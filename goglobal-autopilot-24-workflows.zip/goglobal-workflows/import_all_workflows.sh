#!/bin/bash
# ============================================================
# GoGlobal AutoPilot — Bulk Workflow Importer
# Run AFTER n8n is live at N8N_HOST with credentials set
# ============================================================

set -e
source .env

N8N_URL="${N8N_HOST:-http://localhost:5678}"
AUTH="$N8N_BASIC_AUTH_USER:$N8N_BASIC_AUTH_PASSWORD"
IMPORTED=0
FAILED=0

echo "╔══════════════════════════════════════════════╗"
echo "║  GoGlobal AutoPilot — Workflow Importer     ║"
echo "╚══════════════════════════════════════════════╝"
echo ""
echo "Target: $N8N_URL"
echo ""

import_workflow() {
  local file="$1"
  local name=$(basename "$file" .json)

  response=$(curl -s -w "\n%{http_code}" \
    -X POST "$N8N_URL/rest/workflows" \
    -u "$AUTH" \
    -H "Content-Type: application/json" \
    -d @"$file")

  status=$(echo "$response" | tail -1)
  body=$(echo "$response" | head -1)

  if [[ "$status" == "200" || "$status" == "201" ]]; then
    wf_id=$(echo "$body" | python3 -c "import sys,json; print(json.load(sys.stdin).get('id','?'))" 2>/dev/null || echo "?")
    echo "  ✅ $name (ID: $wf_id)"
    IMPORTED=$((IMPORTED + 1))
  else
    echo "  ❌ $name — HTTP $status"
    FAILED=$((FAILED + 1))
  fi
}

echo "📂 HR Workflows (6):"
for f in hr/WF*.json; do import_workflow "$f"; done

echo ""
echo "📂 Sales Workflows (5):"
for f in sales/WF*.json; do import_workflow "$f"; done

echo ""
echo "📂 Payroll Workflows (3):"
for f in payroll/WF*.json; do import_workflow "$f"; done

echo ""
echo "📂 Marketing Workflows (4):"
for f in marketing/WF*.json; do import_workflow "$f"; done

echo ""
echo "📂 Operations Workflows (6):"
for f in operations/WF*.json; do import_workflow "$f"; done

echo ""
echo "══════════════════════════════════════════════"
echo "  ✅ Imported: $IMPORTED  |  ❌ Failed: $FAILED"
echo "══════════════════════════════════════════════"
echo ""
echo "Next: Open $N8N_URL and add credentials for each service."
echo "See MASTER_CREDENTIALS_TEMPLATE.env for the full list."
